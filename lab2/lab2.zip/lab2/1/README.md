## AIM
Write a simple TCP iterative server and client to evaluate the given expression. The client enters an infix expression and sends to the server. There may or may not be spaces before and after the operators. For example, all of the following are valid expressions to enter: “13 + 42*5”, “10+2/4”, “5 + 6 - 3”. The server evaluates the postfix expression and sends the result back to the client. The client displays the result on the screen. It then prompts the user to enter the next expression.

## ALGORITHM
