##AIM
Implement a 2 player Tic Tac Toe Game using socket programming. There should be at least 2 programs - client playing the game and the server, and a supervising server conducting the game. It should display proper result on game completion.

##ALGORITHM
