## AIM
Implement a mini chat app using socket programming. Clients must be able to chat with each other (as users can in WhatsApp and InstaGram). The server must supervise all these chats and enable communication between them.

## ALGORITHM


