import socket

ip = "localhost"
port = 8089
server = socket.socket()
server.bind((ip, port))
server.listen()
connection, address = server.accept()
print("connected to client: ", address)
data = float(connection.recv(1024).decode())
print("got float", str(data))
connection.close()

connection, address = server.accept()
print("connected to client: ", address)
data = str(float(data**1.5))
print("sending float", str(data))
connection.send(data.encode())
connection.close()