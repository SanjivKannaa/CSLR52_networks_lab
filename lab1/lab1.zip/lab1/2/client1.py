import socket

ip = "localhost"
port = 8089
client = socket.socket()
client.connect((ip, port))
# print("connected to client: ", address)
data = float(input("enter the float number: "))
client.send(str(data).encode())
# data = connection.recv(1024).decode()
# print("message from server: ", data)
client.close()