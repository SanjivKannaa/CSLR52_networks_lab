import socket

ip = "localhost"
result = []
start = int(input("enter the start port number: "))
end = int(input("enter the end port number: "))

for port in range(start, end+1):
    try:
        connection = socket.socket()
        connection.connect((ip, port))
        connection.close()
        result.append(port)
    except:
        pass

print("open ports are: " + str(result))