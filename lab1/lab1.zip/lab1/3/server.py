import socket

def list_addition(data):
    arr1, arr2 = data.split('|')
    arr1 = [int(i) for i in arr1.split(" ")]
    arr2 = [int(i) for i in arr2.split(" ")]
    if len(arr1)!=len(arr2):
        return ""
    for i in arr1:
        if int(i)!=i or i%2!=0:
            return ""
    for i in arr2:
        if int(i)!=i or i%2!=0:
            return ""
    arr3 = []
    for i in range(len(arr1)):
        arr3.append(arr1[i]+arr2[i])
    return arr3
    

ip = "localhost"
port = 2223
server = socket.socket()
server.bind((ip, port))
server.listen()
while True:
    connection, address = server.accept()
    print("connected to client: ", address)
    data = connection.recv(1024).decode()

    data = list_addition(data)

    if data!="":
        connection.send(str(data).encode())
        connection.close()