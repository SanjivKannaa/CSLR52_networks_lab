import time
import socket

remaining_timeout = 3
ip = "localhost"
port = 2223
# client = socket.socket()
# client.connect((ip, port))
while remaining_timeout>0:
    client = socket.socket()
    client.settimeout(3)
    client.connect((ip, port))
    arr1 = input("enter the array1 (seperated by space \" \"): ")
    arr2 = input("enter the array2 (seperated by space \" \"): ")
    data = arr1+"|"+arr2
    client.send(str(data).encode())
    try:
        data = client.recv(1024).decode()
        if data!="":
            print("message from client: " + data)
    except:
        print("timeout")
        remaining_timeout-=1
    client.close()
print("max timeout reached")