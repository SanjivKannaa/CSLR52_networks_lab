import socket

ip = "localhost"
port = 8080
client = socket.socket()
client.connect((ip, port))
# print("connected to client: ", address)
# connection.send(data.encode())
data = client.recv(1024).decode()
print("message from server: ", data)
client.close()