import socket

ip = "localhost"
port = 8080
client = socket.socket()
client.connect((ip, port))
# print("connected to client: ", address)
data = input("enter the char: ")
client.send(data.encode())
# data = connection.recv(1024).decode()
# print("message from server: ", data)
client.close()