import socket

ip = "localhost"
port = 8089
server = socket.socket()
server.bind((ip, port))
server.listen()
connection, address = server.accept()
print("connected to client: ", address)
data = connection.recv(1024).decode()
connection.close()

connection, address = server.accept()
print("connected to client: ", address)
data = chr(ord(data)-1)
connection.send(data.encode())
connection.close()